<?php
/**
 * Plugin Name: My Admin Speed Monitor
 * Description: Displays page generation time and memory usage in the WordPress Admin Bar.
 * Version:     1.0.2
 * Author:      WP TW Architect
 * Text Domain: my-admin-speed-monitor
 * Domain Path: /languages
 * License:     GPL-2.0+
 * Requires at least: 6.0
 * Requires PHP:      7.4
 */

// 1. 安全性：防止直接存取檔案
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 2. 類別封裝
if ( ! class_exists( 'My_Admin_Speed_Monitor' ) ) {

	class My_Admin_Speed_Monitor {

		/**
		 * 建構式：初始化 Hooks
		 */
		public function __construct() {
			// 移除：load_plugin_textdomain (WP 4.6+ 會依據 Text Domain 自動載入)
			
			// 掛載靜態資源 (CSS/JS)
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );

			// 掛載 Admin Bar 選單
			add_action( 'admin_bar_menu', array( $this, 'add_toolbar_item' ), 999 );
		}

		/**
		 * A. 資源管理 (Assets)
		 */
		public function enqueue_assets() {
			if ( ! is_admin_bar_showing() ) {
				return;
			}

			$plugin_data = get_file_data( __FILE__, array( 'Version' => 'Version' ) );
			$version     = $plugin_data['Version'];

			wp_enqueue_style(
				'my-admin-speed-monitor-style',
				plugins_url( 'assets/css/style.css', __FILE__ ),
				array(),
				$version
			);
		}

		/**
		 * B. 核心邏輯
		 */
		public function add_toolbar_item( $wp_admin_bar ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				return;
			}

			$load_time = timer_stop( 0, 3 );
			$memory    = size_format( memory_get_peak_usage() );
			
			$class_status = 'my-status-green';
			if ( $load_time > 1.0 ) {
				$class_status = 'my-status-red';
			} elseif ( $load_time > 0.5 ) {
				$class_status = 'my-status-orange';
			}

			// 修正重點：Text Domain 必須完全對應外掛 Slug
			$title_text = sprintf(
				/* translators: 1: Seconds, 2: Memory size */
				__( 'Load: %1$ss | Mem: %2$s', 'my-admin-speed-monitor' ),
				$load_time,
				$memory
			);

			$wp_admin_bar->add_node( array(
				'id'    => 'my-speed-monitor',
				'title' => '<span class="my-speed-pill ' . esc_attr( $class_status ) . '">' . esc_html( $title_text ) . '</span>',
				'href'  => '#',
				'meta'  => array(
					'title' => __( 'Server Generation Time & Peak Memory Usage', 'my-admin-speed-monitor' ),
					'class' => 'my-speed-monitor-node',
				),
			) );
		}
	}

	new My_Admin_Speed_Monitor();
}