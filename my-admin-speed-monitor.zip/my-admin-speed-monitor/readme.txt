=== My Admin Speed Monitor ===
Contributors: wptwarchitect
Tags: admin bar, performance, speed, memory usage, debug
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 1.0.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Displays page generation time and peak memory usage in the WordPress Admin Bar.

== Description ==

My Admin Speed Monitor is a lightweight plugin designed for developers and site administrators. It adds a small indicator to the WordPress Admin Bar showing:

* **Page Load Time:** How long the server took to generate the page.
* **Memory Usage:** The peak PHP memory consumed during the request.

It features a color-coded status indicator (Green, Orange, Red) to quickly identify performance bottlenecks.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/my-admin-speed-monitor` directory.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. The speed monitor will appear in your top Admin Bar.

== Changelog ==

= 1.0.2 =
* Fix: Removed discouraged load_plugin_textdomain function.
* Fix: Updated Text Domain to match plugin slug.
* Fix: Removed invalid example.com URIs.
* Update: Tested up to WordPress 6.9.

= 1.0.0 =
* Initial release.